﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Affin
{
    public static class AffineCipher
    {
        public const int numberEnglish = 26;
       

        public static int GCD(int one, int two)
        {
            var result = 0;

            while (two != 0)
            {
                result = one % two;
                one = two;
                two = result;
            }

            return one;
        }

        public static List<object> AlphaSearch(int number)
        {
            var objectCollection = new List<object>();

            for (var i = 1; i < number; i++)
            {
                if (GCD(i, number) == 1)
                {
                    objectCollection.Add(i);
                }
            }

            return objectCollection;
        }

        public static int FindReverse(int module, int alpha)
        {
            var y2 = 0;
            var y1 = 1;
            var q = 0;
            var r = 0;
            var y = 0;

            while (alpha > 0)
            {
                q = module / alpha;
                r = module % alpha;
                y = y2 - q * y1;

                module = alpha;
                alpha = r;
                y2 = y1;
                y1 = y;
            }

            return y2;
        }

        public static string EnglishEncryption(int alpha, int betta, string str)
        {
            var text = String.Empty;

            foreach (var letter in str)
            {
                if ((letter >= 'A') && (letter <= 'Z'))
                {
                    text += Convert.ToChar((alpha * (letter - 65) + betta) % 
                        numberEnglish + 65);
                }
                else if ((letter >= 'a') && (letter <= 'z'))
                {
                    text += Convert.ToChar((alpha * (letter - 97) + betta) % 
                        numberEnglish + 97);
                }
                else
                {
                    text += letter;
                }
            }

            return text;
        }

        

        public static string EnglishDecryption(int alpha, int betta, string str)
        {
            var text = String.Empty;

            var alphaReverse = FindReverse(numberEnglish, alpha);

            foreach (var letter in str)
            {
                if ((letter >= 'A') && (letter <= 'Z'))
                {
                    var result = (alphaReverse * (letter - 65 - betta)) % numberEnglish;
                    if (result < 0)
                    {
                        result += numberEnglish;
                    }
                    text += Convert.ToChar(result + 65);
                }
                else if ((letter >= 'a') && (letter <= 'z'))
                {
                    var result = (alphaReverse * (letter - 97 - betta)) % numberEnglish;
                    if (result < 0)
                    {
                        result += numberEnglish;
                    }
                    text += Convert.ToChar(result + 97);
                }
                else
                {
                    text += letter;
                }
            }

            return text;
        }

        

        public static string EnglishEncryptionRecurrent(int alphaOne, int alphaTwo, 
            int bettaOne, int bettaTwo, string str)
        {
            var text = String.Empty;

            var alpha = alphaOne;
            var betta = bettaOne;
            var alphaTemp = alphaTwo;
            var alphaPrev = 0;
            var bettaTemp = bettaTwo;
            var bettaPrev = 0;

            foreach (var letter in str)
            {
                if ((letter >= 'A') && (letter <= 'Z'))
                {
                    text += Convert.ToChar((alpha * (letter - 65) + betta) % 
                        numberEnglish + 65);
                }
                else if ((letter >= 'a') && (letter <= 'z'))
                {
                    text += Convert.ToChar((alpha * (letter - 97) + betta) % 
                        numberEnglish + 97);
                }
                else
                {
                    text += letter;
                }

                alphaPrev = alpha % numberEnglish;
                alpha = alphaTemp % numberEnglish;
                alphaTemp = alphaTemp * alphaPrev % numberEnglish;

                bettaPrev = betta % numberEnglish;
                betta = bettaTemp % numberEnglish;
                bettaTemp = (bettaTemp + bettaPrev) % numberEnglish;
            }

            return text;
        }

        

        public static string EnglishDecryptionRecurrent(int alphaOne, int alphaTwo, 
            int bettaOne, int bettaTwo, string str)
        {
            var text = String.Empty;

            var alphaReverse = 0;

            var alpha = alphaOne;
            var betta = bettaOne;
            var alphaTemp = alphaTwo;
            var alphaPrev = 0;
            var bettaTemp = bettaTwo;
            var bettaPrev = 0;

            foreach (var letter in str)
            {
                alphaReverse = FindReverse(numberEnglish, alpha);

                if ((letter >= 'A') && (letter <= 'Z'))
                {
                    var result = (alphaReverse * (letter - 65 - betta)) % numberEnglish;
                    if (result < 0)
                    {
                        result += numberEnglish;
                    }
                    text += Convert.ToChar(result + 65);
                }
                else if ((letter >= 'a') && (letter <= 'z'))
                {
                    var result = (alphaReverse * (letter - 97 - betta)) % numberEnglish;
                    if (result < 0)
                    {
                        result += numberEnglish;
                    }
                    text += Convert.ToChar(result + 97);
                }
                else
                {
                    text += letter;
                }

                alphaPrev = alpha % numberEnglish;
                alpha = alphaTemp % numberEnglish;
                alphaTemp = alphaTemp * alphaPrev % numberEnglish;

                bettaPrev = betta % numberEnglish;
                betta = bettaTemp % numberEnglish;
                bettaTemp = (bettaTemp + bettaPrev) % numberEnglish;
            }

            return text;
        }

        
    }
}
