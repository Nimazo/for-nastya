﻿namespace Affin
{
    partial class FormMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.radioButtonRecurrentHill = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.richTextBoxResult = new System.Windows.Forms.RichTextBox();
            this.textBoxBetta = new System.Windows.Forms.TextBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButtonAffine = new System.Windows.Forms.RadioButton();
            this.radioButtonRecurrent = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButtonEncryption = new System.Windows.Forms.RadioButton();
            this.radioButtonDecryption = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox = new System.Windows.Forms.ListBox();
            this.buttonRun = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.radioButtonEnglish2 = new System.Windows.Forms.RadioButton();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.radioButtonDecryption2 = new System.Windows.Forms.RadioButton();
            this.radioButtonEncryption2 = new System.Windows.Forms.RadioButton();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButtonHill = new System.Windows.Forms.RadioButton();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.radioButtonRecurrentHill.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.DefaultExt = "*.rtf";
            this.saveFileDialog.Filter = "RTF Files|*.rtf";
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "RTF Files|*.rtf";
            // 
            // radioButtonRecurrentHill
            // 
            this.radioButtonRecurrentHill.Controls.Add(this.tabPage1);
            this.radioButtonRecurrentHill.ItemSize = new System.Drawing.Size(320, 18);
            this.radioButtonRecurrentHill.Location = new System.Drawing.Point(12, 12);
            this.radioButtonRecurrentHill.Name = "radioButtonRecurrentHill";
            this.radioButtonRecurrentHill.SelectedIndex = 0;
            this.radioButtonRecurrentHill.Size = new System.Drawing.Size(649, 476);
            this.radioButtonRecurrentHill.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.radioButtonRecurrentHill.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.richTextBox);
            this.tabPage1.Controls.Add(this.richTextBoxResult);
            this.tabPage1.Controls.Add(this.textBoxBetta);
            this.tabPage1.Controls.Add(this.listBox2);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.listBox);
            this.tabPage1.Controls.Add(this.buttonRun);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(641, 450);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(89, 383);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 26;
            this.label16.Text = "Бета 2";
            this.label16.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 384);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(31, 13);
            this.label15.TabIndex = 25;
            this.label15.Text = "Бета";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(89, 87);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Альфа 2";
            this.label11.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "Альфа";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(158, 370);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 13);
            this.label8.TabIndex = 22;
            this.label8.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(158, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 13);
            this.label9.TabIndex = 21;
            this.label9.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(92, 400);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(49, 20);
            this.textBox2.TabIndex = 20;
            this.textBox2.Visible = false;
            // 
            // richTextBox
            // 
            this.richTextBox.Location = new System.Drawing.Point(147, 84);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.richTextBox.Size = new System.Drawing.Size(290, 144);
            this.richTextBox.TabIndex = 11;
            this.richTextBox.Text = "";
            // 
            // richTextBoxResult
            // 
            this.richTextBoxResult.Location = new System.Drawing.Point(147, 263);
            this.richTextBoxResult.Name = "richTextBoxResult";
            this.richTextBoxResult.ReadOnly = true;
            this.richTextBoxResult.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.richTextBoxResult.Size = new System.Drawing.Size(290, 157);
            this.richTextBoxResult.TabIndex = 7;
            this.richTextBoxResult.Text = "";
            // 
            // textBoxBetta
            // 
            this.textBoxBetta.Location = new System.Drawing.Point(15, 400);
            this.textBoxBetta.Name = "textBoxBetta";
            this.textBoxBetta.Size = new System.Drawing.Size(49, 20);
            this.textBoxBetta.TabIndex = 6;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(92, 103);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(49, 264);
            this.listBox2.TabIndex = 19;
            this.listBox2.Visible = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButtonAffine);
            this.panel3.Controls.Add(this.radioButtonRecurrent);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(3, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(166, 62);
            this.panel3.TabIndex = 17;
            // 
            // radioButtonAffine
            // 
            this.radioButtonAffine.AutoSize = true;
            this.radioButtonAffine.Checked = true;
            this.radioButtonAffine.Location = new System.Drawing.Point(9, 6);
            this.radioButtonAffine.Name = "radioButtonAffine";
            this.radioButtonAffine.Size = new System.Drawing.Size(80, 17);
            this.radioButtonAffine.TabIndex = 1;
            this.radioButtonAffine.TabStop = true;
            this.radioButtonAffine.Text = "Аффинный";
            this.radioButtonAffine.UseVisualStyleBackColor = true;
            this.radioButtonAffine.CheckedChanged += new System.EventHandler(this.radioButtonAffine_CheckedChanged);
            // 
            // radioButtonRecurrent
            // 
            this.radioButtonRecurrent.AutoSize = true;
            this.radioButtonRecurrent.Location = new System.Drawing.Point(9, 29);
            this.radioButtonRecurrent.Name = "radioButtonRecurrent";
            this.radioButtonRecurrent.Size = new System.Drawing.Size(155, 17);
            this.radioButtonRecurrent.TabIndex = 2;
            this.radioButtonRecurrent.Text = "Аффинный рекуррентный";
            this.radioButtonRecurrent.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButtonEncryption);
            this.panel2.Controls.Add(this.radioButtonDecryption);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(310, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(127, 62);
            this.panel2.TabIndex = 16;
            // 
            // radioButtonEncryption
            // 
            this.radioButtonEncryption.AutoSize = true;
            this.radioButtonEncryption.Checked = true;
            this.radioButtonEncryption.Location = new System.Drawing.Point(9, 6);
            this.radioButtonEncryption.Name = "radioButtonEncryption";
            this.radioButtonEncryption.Size = new System.Drawing.Size(102, 17);
            this.radioButtonEncryption.TabIndex = 1;
            this.radioButtonEncryption.TabStop = true;
            this.radioButtonEncryption.Text = "Зашифрование";
            this.radioButtonEncryption.UseVisualStyleBackColor = true;
           
            // 
            // radioButtonDecryption
            // 
            this.radioButtonDecryption.AutoSize = true;
            this.radioButtonDecryption.Location = new System.Drawing.Point(9, 29);
            this.radioButtonDecryption.Name = "radioButtonDecryption";
            this.radioButtonDecryption.Size = new System.Drawing.Size(108, 17);
            this.radioButtonDecryption.TabIndex = 2;
            this.radioButtonDecryption.Text = "Расшифрование";
            this.radioButtonDecryption.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(216, 263);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(216, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(103, 370);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(103, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 9;
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(15, 103);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(49, 264);
            this.listBox.TabIndex = 5;
            // 
            // buttonRun
            // 
            this.buttonRun.Location = new System.Drawing.Point(242, 234);
            this.buttonRun.Name = "buttonRun";
            this.buttonRun.Size = new System.Drawing.Size(105, 23);
            this.buttonRun.TabIndex = 4;
            this.buttonRun.Text = "Выполнить";
            this.buttonRun.UseVisualStyleBackColor = true;
            this.buttonRun.Click += new System.EventHandler(this.buttonRun_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 6);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(86, 13);
            this.label14.TabIndex = 8;
            // 
            // radioButtonEnglish2
            // 
            this.radioButtonEnglish2.AutoSize = true;
            this.radioButtonEnglish2.Checked = true;
            this.radioButtonEnglish2.Location = new System.Drawing.Point(95, 4);
            this.radioButtonEnglish2.Name = "radioButtonEnglish2";
            this.radioButtonEnglish2.Size = new System.Drawing.Size(114, 17);
            this.radioButtonEnglish2.TabIndex = 1;
            this.radioButtonEnglish2.TabStop = true;
            this.radioButtonEnglish2.Text = "Английский язык";
            this.radioButtonEnglish2.UseVisualStyleBackColor = true;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(0, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(100, 50);
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 6);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 13);
            this.label13.TabIndex = 8;
            // 
            // radioButtonDecryption2
            // 
            this.radioButtonDecryption2.AutoSize = true;
            this.radioButtonDecryption2.Location = new System.Drawing.Point(101, 29);
            this.radioButtonDecryption2.Name = "radioButtonDecryption2";
            this.radioButtonDecryption2.Size = new System.Drawing.Size(108, 17);
            this.radioButtonDecryption2.TabIndex = 2;
            this.radioButtonDecryption2.Text = "Расшифрование";
            this.radioButtonDecryption2.UseVisualStyleBackColor = true;
            // 
            // radioButtonEncryption2
            // 
            this.radioButtonEncryption2.Location = new System.Drawing.Point(0, 0);
            this.radioButtonEncryption2.Name = "radioButtonEncryption2";
            this.radioButtonEncryption2.Size = new System.Drawing.Size(104, 24);
            this.radioButtonEncryption2.TabIndex = 0;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(0, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(100, 50);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 8;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(41, 29);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(131, 17);
            this.radioButton2.TabIndex = 2;
            this.radioButton2.Text = "Хилла рекуррентный";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButtonHill
            // 
            this.radioButtonHill.Location = new System.Drawing.Point(0, 0);
            this.radioButtonHill.Name = "radioButtonHill";
            this.radioButtonHill.Size = new System.Drawing.Size(104, 24);
            this.radioButtonHill.TabIndex = 0;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 50);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(477, 500);
            this.Controls.Add(this.radioButtonRecurrentHill);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.Text = "Аффинный и Аффинный рекурентный шифры";
            this.radioButtonRecurrentHill.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.TabControl radioButtonRecurrentHill;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton radioButtonEnglish2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RadioButton radioButtonDecryption2;
        private System.Windows.Forms.RadioButton radioButtonEncryption2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButtonHill;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.RichTextBox richTextBoxResult;
        private System.Windows.Forms.TextBox textBoxBetta;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Button buttonRun;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton radioButtonDecryption;
        private System.Windows.Forms.RadioButton radioButtonEncryption;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton radioButtonRecurrent;
        private System.Windows.Forms.RadioButton radioButtonAffine;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
    }
}

