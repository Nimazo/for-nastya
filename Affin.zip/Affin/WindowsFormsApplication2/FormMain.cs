﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;


namespace Affin
{
    public partial class FormMain : Form
    {
        private static List<object> AlphaForEnglish;

        private void buttonRun_Click(object sender, EventArgs e)
        {
            richTextBoxResult.Text = String.Empty;

            var alpha = Convert.ToInt32(listBox.SelectedItem);
            var betta = 0;
            try
            {
                betta = Convert.ToInt32(textBoxBetta.Text);

                if (betta < 0)
                {
                    throw new Exception();
                }

                
                    if (radioButtonEncryption.Checked)
                    {
                        if (radioButtonAffine.Checked)
                        {
                            richTextBoxResult.Text = 
                                AffineCipher.EnglishEncryption(alpha, betta, 
                                richTextBox.Text);
                        }
                        else
                        {
                            var alpha2 = Convert.ToInt32(listBox2.SelectedItem);
                            var betta2 = Convert.ToInt32(textBox2.Text);
                            richTextBoxResult.Text = 
                                AffineCipher.EnglishEncryptionRecurrent(alpha, 
                                alpha2, betta, betta2, richTextBox.Text);
                        }
                    }
                    else
                    {
                        if (radioButtonAffine.Checked)
                        {
                            richTextBoxResult.Text = 
                                AffineCipher.EnglishDecryption(alpha, betta, 
                                richTextBox.Text);
                        }
                        else
                        {
                            var alpha2 = Convert.ToInt32(listBox2.SelectedItem);
                            var betta2 = Convert.ToInt32(textBox2.Text);
                            richTextBoxResult.Text = 
                                AffineCipher.EnglishDecryptionRecurrent(alpha, 
                                alpha2, betta, betta2, richTextBox.Text);
                        }
                    }
                
                
            }
            catch
            {
                MessageBox.Show("Проверьте корректность введенного значения.", "Ошибка!",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        

        private void RadioButtonCheckedChanged()
        {
            listBox.Items.Clear();
            listBox2.Items.Clear();
                       
                listBox.Items.AddRange(AlphaForEnglish.ToArray());
                listBox2.Items.AddRange(AlphaForEnglish.ToArray());
           

            listBox.SelectedIndex = 0;
            listBox2.SelectedIndex = 0;
        }

        

        

        private void radioButtonAffine_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonAffine.Checked)
            {
                label11.Visible = false;
                label16.Visible = false;
                listBox2.Visible = false;
                textBox2.Visible = false;
            }
            else
            {
                label11.Visible = true;
                label16.Visible = true;
                listBox2.Visible = true;
                textBox2.Visible = true;
            }
        }
         
        public FormMain()
        {
            InitializeComponent();

            AlphaForEnglish = AffineCipher.AlphaSearch(AffineCipher.numberEnglish);
           

            RadioButtonCheckedChanged();
            
        }

        
    }
}
